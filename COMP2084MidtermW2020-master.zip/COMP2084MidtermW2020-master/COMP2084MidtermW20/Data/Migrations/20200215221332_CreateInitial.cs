﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace COMP2084MidtermW20.Data.Migrations
{
    public partial class CreateInitial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
